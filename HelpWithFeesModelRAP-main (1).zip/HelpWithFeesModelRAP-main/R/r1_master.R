## r1_master

setwd("~/R_Projects/HelpWithFeesModelRAP")
# devtools::create("~/R_Projects/HelpWithFeesModelRAP")
######################################### ##
## ##
#source("R/create_data_object.R")
## ## ############  Testing   ################################# ##

## run r0_installation.R only once
## and then run:
## renv::snapshot() # choose y twice
## if one of two commend failed then run r0_installation.R
### Fixing issue with Athena Table:
#botor::botor() # to check what region is set
#botor::s3_list_buckets() # to check if it's working
## otherwise (else):
## renv::snapshot() # choose y twice
##
## source("R/r0_installation.R")
gc()
renv::restore()

## Read psm data in and save it into psm_data
source("R/r2_weighting_data.R")
gc()
## civil_weight
source("R/r3_civil_weight.R")
gc()
## divorce_weight
source("R/r4_divorce_weight.R")
gc()
## #################  Setting Up variables    ######################## ##
##
## record age of respondents (in years) and sorts it into the appropriate age band

## Generate flag for self-employment status
## WeightingsDF
source("R/r5_age_bands.R")
gc()
## Migrating to join for Merging on the weights
## WeightingsDF_2
source("R/r6_merge.R")

gc()
##  Adjusted Data (manipulated by weighting)
## Cleaning, Migrating and simplifying
## WeightingsDF_2
## Create the weights to use in the main HwF test
## create the HwF_civil_weight and HwF_divorce_weight weightings
source("R/r7_manipulate.R")
gc()
## #################  Data Access    ######################## ##
## Migrating to the new s3tools
##  Using botor as a replacement of aws.s3
source("R/r8_data_access.R")
gc()
## #################  Setting Up variables  ######################## ##

## Cleaning, Migrating and simplifying
## ranks the income scores and assigns percentile rankings
## The percentile ranks are merged onto the private law dataset by LSOA
## The private law percentiles are exported
## and an excel file creates the adjustments
## that need to be made to the main weights.
## This happens in the main part of the code.
## output:
## private_law_LSOA
source("R/r9_weighting_adjust.R")
gc()
## ###### Next step is to 'Run_the_remission_test.R ################  ##
## ######################################################################## ##
## ######################################################################## ##
## Prepration before test ----------------------------------------------------
## ######################################################################## ##
## ######################## old code ############################### ##

# *** Run Set_up_Weights.R first ***

#This is the code to run the remissions test on the PSM data.
#This code is set to run the current HwF option
#To model an alternative, take a copy of the code and change the parameters on the
#main test from line 316 onwards


## This happens in the main part of the code.
## input:
## WeightingsDF_2
##
## output:
## df_working
##
## Create df_working dataframe by taking copy of WeightingsDF_2 datframe from Set_up_Weights.R
## This was done during model development to ensure that there was a clean copy of the original dataframe to roll back to.
## It's not strictly necessary to do this when the model is operating normally, but will be useful when making changes
##
## Add the cleaned-up spouse earnings to head of household earnings
##
source("R/r10_test_setup_variables.R")
gc()
## ##################################################################  ##
## #################  calculation    ######################## ##
## Calculating Gross weekly incomes
## input:
## df_working
##
## output:
## df_working (Calculated Equivalisations)
##
##
##
##
source("R/r11_test_calculation.R")
gc()
## ##################################################################  ##
## #################  percentiles    ######################## ##
## CREATE THE PRIVATE LAW PERCENTILES
## First, the equvalised PSM income is ranked and arranged into percentiles.
## This percentiles are adjusted to match the private law distribution in the 'set_up_weights' code.
## input:
## df_working (Calculated Equivalisations)
##
## output:
## Re_weighted_table
##
##
##
##
source("R/r12_test_percentile.R")
gc()
##
## ######################################################################## ##
## ####################  Setting parameters for testing  #################  ##
## ######################################################################## ##
## ######################################################################## ##
## Setting parameters
## Need to configure this so it checks against the fee and applies the correct weights and file names
## Fee variable can be a vector of values - in this case, the model will run each of the fee values sequentially and provide outputs for each of them
## This uses the file_names list (see below) to create names for the output files/output rows
##
## input:
## constants
##
## output:
## Output_SUMS
##
##
##
##
source("R/r13_test_setting_parameters.R")
gc()
## ###################################################################  ##
## #####################  Calculating HwF thresholds #################  ##
##
## input:
## df_working (PRIVATE LAW PERCENTILES)
##
## output:
## Output_SUMS
##
##
##
##
source("R/r14_test_HwF_thresholds.R")
gc()
##
