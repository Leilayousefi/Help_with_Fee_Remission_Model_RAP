
## Function create_data_object
##
##
## Creates data objects from s3 csv files and
## Return RDA objects
## output: data_RDAobj

## input arguments:
## s3_path : path_s3_bucket_csv : an string path to a S3 bucket CSV file
## format: "s3://.../....csv"
##
##FUN : function to read different type of data
##
## Output: RDA object
## #
##
## rda : data table from red_using function
##
## dataset_type : based on if_else(condition, true, false, missing = NULL)
## ## condition
## tibble: 1 (default)
## data.frame: 2
##

##
## Last edit: 07032022
#Edited by: Leila Yousefi

## ######################### Setting up Data ####################### ##
##
# create_data_object <- function(FUN, s3_path, dataset_type, ...) {
#
#   ## missing(FUN), missing(s3_path))
#   ## missing(dataset_type))
#   ##
#   ## Setting up default arguments:
#   ##
#   if(missing(FUN)){
#     FUN <- data.table::fread
#   }
#
#   if(missing(s3_path)){
#     s3_path <- 's3://alpha-help-with-fees-model/_1_frs_psm_manipulation.csv'
#   }
#
#   if(missing(dataset_type)){
#     dataset_type <- 1  # tibble: 1 (default)
#   }
#
#   # trim s3:// if included by the user
#   s3_path <- paste0("s3://", gsub('^s3://', "", s3_path))
#   # find file ext
#   file_ext <- paste0('.', tolower(tools::file_ext(s3_path)))
#   # download file to tempfile()
#   tmp <- botor::s3_download_file(s3_path,
#                                  tempfile(fileext = file_ext),
#                                  force = TRUE)
#   FUN(tmp, ...)
#   ##
#   ##  S3 bucket CSV file
#   rda <- FUN(tmp, ...)
#
#   # Implementation of the SAS HwF weightings in R
#   #
#   ## Read S3 bucket CSV file and convert it to a data.table
#   #  rda <- s3_read("s3://alpha-help-with-fees-model/_1_frs_psm_manipulation.csv", data.table::fread)
#
#   ## Creates a tibble/dataframe from the data imported from the data.table(rda)
#   rda <- if (dataset_type == 2) {rda = data.frame(rda)} else {rda = as_tibble(rda)}
#
#   ## ###################  RDA object ######################### ##
#   ##
#   ## go from raw data csv to a RDA object
#   ##
#   #dataRDAobject <-
#   usethis::use_data(rda, overwrite = TRUE)
#
#   return(rda)
# }
## Function create_data_object
##
##
## Creates data objects from s3 csv files and
## Return RDA objects
## output: data_RDAobj

## input arguments:
## s3_path : path_s3_bucket_csv : an string path to a S3 bucket CSV file
## format: "s3://.../....csv"
##
##FUN : function to read different type of data
##
## Output: RDA object
## #
##
## rda : data table from red_using function
##
## dataset_type : based on if_else(condition, true, false, missing = NULL)
## ## condition
## tibble: 1 (default)
## data.frame: 2
##

##
## Last edit: 07032022
#Edited by: Leila Yousefi

## ######################### Setting up Data ####################### ##

create_data_object <- function(FUN, s3_path, dataset_type, rda) {

  ## missing(FUN), missing(s3_path))
  ## missing(dataset_type))
  ##
  ## Setting up default arguments:
  ##
  gc()

  if(missing(FUN)){
    FUN <- data.table::fread
  }

  if(missing(s3_path)){
    s3_path <- 's3://alpha-hr-arm-main/data/oleeo_data/processed_data/recruitment_main_data/Jan-22/All_Applications_Jan-22.csv'
  }

  if(missing(dataset_type)){
    dataset_type <- 1  # tibble: 1 (default)
  }

  # trim s3:// if included by the user
  s3_path <- paste0("s3://", gsub('^s3://', "", s3_path))
  # find file ext
  file_ext <- paste0('.', tolower(tools::file_ext(s3_path)))
  # download file to tempfile()
  tmp <- botor::s3_download_file(s3_path,
                                 tempfile(fileext = file_ext),
                                 force = TRUE)
  #FUN(tmp,...)
  ##
  ##  S3 bucket CSV file
  #downloded_file <- FUN(tmp,...)
  dt <- FUN(tmp)

  # Implementation of the SAS HwF weightings in R
  #
  ## Read S3 bucket CSV file and convert it to a data.table1
  ##
  #  rda <- s3_read("s3://alpha-help-with-fees-model/_1_frs_psm_manipulation.csv", data.table::fread)

  ## Creates a tibble/dataframe from the data imported from the data.table(rda)
  dt <- if (dataset_type == 2) {dt = data.frame(dt)} else {dt = tidyr::as_tibble(dt)}
  ## if (dataset_type == 2) {data.frame(FUN(tmp,...))} else {as_tibble(FUN(tmp,...))}
  ## ###################  RDA object ######################### ##
  ##
  ## go from raw data csv to a RDA object
  ##
  rda <- dt
  usethis::use_data(rda, overwrite = TRUE, ... = rda)
  #rename_files(rda, new)
  #return(rda)
}

## Loading HelpWithFeesModelRAP
# devtools::document(roclets = c('rd', 'collate', 'namespace', 'vignette'))
# devtools::load_all(".")
# devtools::check()
#
