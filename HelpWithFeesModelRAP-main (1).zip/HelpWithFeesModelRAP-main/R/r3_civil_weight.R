
## ######################### Setting up Data ####################### ##
## Function create_data_object
## Creates data objects from s3 csv files and
## Return RDA objects
## Output: RDA object

## input arguments: -----------------------------------------------------


## Read S3 bucket CSV files and convert it to a data.table and then tibble
##
## Civil data------------------------------------------------
##
## FUN : function to read different type of data (tibble)
FUN <- readr::read_csv

## s3_path : path_s3_bucket_csv : an string path to a S3 bucket CSV file
s3_path <- "s3://alpha-help-with-fees-model/CCUS_weights.csv"
## Read in civil_weight data in and save it into civil_weight as a data.table
civil_weight <- botor::s3_read(s3_path, FUN, show_col_types = FALSE)
# civil_weight dataset brings in the adjustment that
# is needed to the weights for civil users.



