## ######################################### ##
## ###########  Adjusted Data (manipulated by weighting)   ########## ##
##
#Create the weights to use in the main HwF test
#This creates the HwF_civil_weight and HwF_divorce_weight weightings
## Cleaning, Migrating and simplifying
WeightingsDF_2 <- WeightingsDF_2 %>%
  mutate(HwF_civil_weight = PSM_Grossing_Factor*CCUS_Weight) %>%
  mutate(HwF_divorce_weight = PSM_Grossing_Factor*Divorce_weight)

WeightingsDF_2 <- subset(WeightingsDF_2, select = -c(CCUS_Weight,Divorce_weight))


head(WeightingsDF_2)
