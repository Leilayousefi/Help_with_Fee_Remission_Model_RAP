## #################  calculation    ######################## ##
## ##################################################################  ##
#Calculating Gross weekly incomes
#Need to turn the following into numeric classes -
#   PSM_Tax_inc_sp
#   PSM_Non_Tax_inc_sp
df_working <-
  df_working %>%
  mutate(PSM_Tax_inc_sp =
                          replace(PSM_Tax_inc_sp, PSM_Tax_inc_sp ==
                                                   'A', 0))
df_working <-
  df_working %>%
  mutate(PSM_Tax_inc_sp =
           as.numeric(PSM_Tax_inc_sp))

df_working <-
  df_working %>%
  mutate(PSM_Non_Tax_inc_sp =
                          replace(PSM_Non_Tax_inc_sp, PSM_Non_Tax_inc_sp ==
                                                       'A', 0))
df_working <-
  df_working %>%
  mutate(PSM_Non_Tax_inc_sp =
           as.numeric(PSM_Non_Tax_inc_sp))

#Calculate EM_GrossInc_Wk by summing columns
#These columns correspond to benefits received by respondents to the PSM
df_working <-
  df_working %>%
  mutate(
    EM_GrossInc_Wk = PSM_Tax_inc_hd +
      PSM_Non_Tax_inc_hd +
      PSM_Tax_inc_sp +
      PSM_Non_Tax_inc_sp +
      PSM_Child_Benefit +
      PSM_L_Income_Support_Wk +
      PSM_L_ESA_Wk +
      PSM_L_Pension_Credit_Wk2 +
      PSM_L_Housing_Benefit_Wk +
      PSM_L_Working_Tax_Credits_wk +
      PSM_L_Child_Tax_Credits_wk +
      EM_JSA_Wk +
      PSM_Council_Rebate_Wk +
      PSM_Winter_Value_Payments +
      PSM_Free_TV_License +
      PSM_in_Work_Credits +
      PSM_Return_to_work
  )

#Calculate EM_Income_Under_UC_wk by adding and subtracting columns
df_working <-
  df_working %>%
  mutate(
    EM_Income_Under_UC_Wk = EM_GrossInc_Wk +
      PSM_Universal_Credit_Take_Up -
      #Now take away the deductions of the old legacy value
      PSM_L_Income_Support_Wk -
      PSM_L_ESA_Wk -
      PSM_L_Pension_Credit_Wk2 -
      PSM_L_Housing_Benefit_Wk -
      PSM_L_Working_Tax_Credits_wk -
      PSM_L_Child_Tax_Credits_wk -
      EM_JSA_Wk +
      #Add in the post_UC values of legacy benefits (very small and rare)
      PSM_Income_Support_Wk +
      PSM_ESA_Wk +
      PSM_Pension_Credit_Wk2 +
      PSM_Housing_Benefit_Wk +
      PSM_Working_Tax_Credits_wk +
      PSM_Child_Tax_Credits_wk
  )

#Turn EM_GrossInc_Wk and EM_Income_Under_UC_Wk into monthly amounts
df_working <-
  df_working %>%
  mutate(EM_GrossInc_M = EM_GrossInc_Wk * (52 / 12))
df_working <-
  df_working %>%
  mutate(EM_Income_Under_UC_M = EM_Income_Under_UC_Wk * (52 /
                                                                          12))

#This is the list of benefits that are disregarded from income, it is not comprehensive and needs to be looked at
#Calculate UC_Housing_Disregard
df_working <-
  df_working %>%
  mutate(UC_Housing_Disregard = PSM_Universal_Credit_Housing)

df_working <-
  df_working %>%
  mutate(
    UC_Housing_Disregard = if_else(
      UC_Housing_Disregard > PSM_Universal_Credit_Take_Up,
      PSM_Universal_Credit_Take_Up,
      UC_Housing_Disregard
    )
  )

#Calculate Disregarded_Income_Legacy_Wk
#EM_Constant_Attendance_wk taken out as not in income calc
df_working <-
  df_working %>%
  mutate(
  Disregarded_Income_Legacy_Wk =
    EM_War_Pension_Wk +
    PSM_Attendance_Wk +
    EM_Severe_Disablement_Wk +
    PSM_L_Housing_Benefit_Wk +
    PSM_Carers_Wk +
    PSM_DLA_Carers_Wk +
    PSM_DLA_Mobility_Wk +
    PSM_PIP_Carers_Head_Wk +
    PSM_PIP_Carers_Spouse_Wk +
    PSM_PIP_Mobility_Head_Wk +
    PSM_PIP_Mobility_Spouse_Wk +
    PSM_Winter_Value_Payments
)

#Calculate Disregarded_Income_UC_Wk
df_working <-
  df_working %>%
  mutate(
  Disregarded_Income_UC_Wk =
    EM_War_Pension_Wk +
    UC_Housing_Disregard +
    PSM_Attendance_Wk +
    EM_Severe_Disablement_Wk +
    PSM_Housing_Benefit_Wk +
    PSM_Carers_Wk +
    PSM_DLA_Carers_Wk +
    PSM_DLA_Mobility_Wk +
    PSM_PIP_Carers_Spouse_Wk +
    PSM_PIP_Carers_Head_Wk +
    PSM_PIP_Mobility_Head_Wk +
    PSM_PIP_Mobility_Spouse_Wk +
    PSM_Winter_Value_Payments)

df_working <-
  df_working %>%
  mutate (Disregarded_Income_Legacy_M =
            Disregarded_Income_Legacy_Wk*52/12)

df_working <-
  df_working %>%
  mutate (Disregarded_Income_UC_M =
            Disregarded_Income_UC_Wk*52/12)

#Means testing
#Sets passport_legacy flag to true (1) if applicant is in receipt of pension credit, income support, employment support allowance or jobseekers allowance
df_working <-
  df_working %>%
  mutate(
    passport_legacy = if_else(
      PSM_L_Pension_Credit_Wk1 > 0 |
        PSM_L_Income_Support_Wk > 0 |
        PSM_L_ESA_Wk > 0 | EM_JSA_Wk > 0,
      1,
      0
    )
  )

#Sets passport_UC flag to true (1) if applicant is in receipt of universal credit and the benefit unit as a whole earns less than £6,000 per annum
df_working$passport_UC <- 0

df_working <-
  df_working %>%
  mutate(passport_UC = if_else(
    PSM_Universal_Credit_Take_Up > 0 &
      BU_Earnings_A < 6000,
    1,
    passport_UC
  ))

#Sets passport_UC flag to true (1) if applicant is in receipt of income support, employment support allowance or pension credit
df_working <-
  df_working %>%
  mutate(
    passport_UC = if_else(
      PSM_Income_Support_Wk > 0 |
        PSM_ESA_Wk > 0 | PSM_Pension_Credit_Wk1 > 0,
      1,
      passport_UC
    )
  )

#Note: there are 35 household receiving guarantee credit and UC, think this is where there are
#two people in the household

#Equavalise household income, so can reweight for private law
#First, calculate children under and over 14
df_working <-
  df_working %>%
  mutate(
  children_under_14 =
    FRS_Children_0_1 +
    FRS_Children_2_4 +
    FRS_Children_5_7 +
    FRS_Children_8_10 +
    FRS_Children_11_12 +
    FRS_Children_13
)

df_working <-
  df_working %>%
  mutate(children_14plus =
                                      FRS_Children_14 +
                                      FRS_Children_15 +
                                      FRS_Children_16_18)#Check - just children in FTE?

#Calculate Equivalisations
#SAS code = equivalisation=1 + ((FRS_Adult_count_BU - 1)*0.5) +(children_under14*0.3) + (children_14plus*0.5);
#SAS code = monthlyincome_equivalised=EM_Income_under_UC_m/equivalisation;
df_working <-
  df_working %>%
  mutate(
  equivalisation = 1+ (FRS_Adult_Count_BU - 1)*0.5 + (children_under_14*0.3) + (children_14plus*0.5))
df_working <-
  df_working %>%
  mutate(
  monthlyincome_equivalised=EM_Income_Under_UC_M/equivalisation)
