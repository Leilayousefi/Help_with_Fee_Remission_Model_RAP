# ## ############################################################## ##
## install required packages:
packages = c("usethis", "roxygen2", "devtools", "testthat", "tidyverse", "knitr", "tidyr", "dplyr", "dbplyr", "haven", "ggplot2", "stringr", "datasets", "rmarkdown", "datasets", "timeDate", "bizdays")#, "botor", "moj-analytical-services/mojverse", "moj-analytical-services/mojrap") # "xltabr", "moj-analytical-services/xltabr", "s3tools", "aws.s3"

## load or install and load all packages listed above
##
package.check <- lapply(
  packages,
  FUN = function(x) {
    if (!require(x, character.only = TRUE)) {
      install.packages(x, dependencies = TRUE)
      library(x, character.only = TRUE)
    }
  }
)

install.packages("moj-analytical-services/Rdbtools")
#The library stringr needs to be installed.
install.packages("data.table", "bit64")
#devtools::install_github("tidyverse/forcats")
#devtools::install_github("garrettgman/DSR",force = TRUE)
#devtools::install_version('text2vec', version='0.5.1')

require(lubridate)
library(lubridate)
library(stringr)
library(dplyr)
library(Rdbtools)
library(data.table)
#library(aws.s3) # for previous version of
library(bit64)
#library(text2vec)
library(botor)
## ############  Testing   ################################# ##

## run r0_installation.R only once
## and then run:
## renv::snapshot() # choose y twice
## if one of two commend failed then run r0_installation.R
### Fixing issue with Athena Table:
#botor::botor() # to check what region is set
#botor::s3_list_buckets() # to check if it's working
## otherwise (else):
## renv::snapshot() # choose y twice

# You’ve just bricked the renv project then.
# Steps to fix it:
# 1. Copy + paste renv.lock into a random empty script (we'll need it in a minute)
# 2. Delete all files relating to renv - renv folder & renv.lock, I believe.
# 3. Reinitialise the renv project - renv::init(bare=TRUE)
# 4. Overwrite the new renv.lock with your copy+pasted renv.lock.
# 5. Follow the botor instructions again
# 6. Test botor works with the list_buckets func
# 7. renv::restore()
# ### ################################################################# ##
