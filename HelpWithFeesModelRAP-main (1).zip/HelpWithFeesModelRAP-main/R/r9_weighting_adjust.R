## Cleaning, Migrating and simplifying
# Using filter() function is used to subset a data frame,
# retaining all rows that satisfy the conditions.

lso_income <- deprivation_scores[ , c('LSOA name (2011)', 'LSOA code (2011)', 'Income Score (rate)')]


## This code ranks the income scores and assigns percentile rankings.
lso_income$Rank_per <-
  percent_rank(lso_income$'Income Score (rate)')


private_law_LSOA$DATE_OF_ISSUE <-
  as.Date(private_law_LSOA$DATE_OF_ISSUE, origin = "1899-12-30")

## The percentile ranks are merged onto the private law dataset by LSOA
private_law_LSOA <-
  select(merge(private_law_LSOA, lso_income,
               by.x=c("Lower_Super_Output_Area_Code"),
               by.y=c("LSOA code (2011)")), -c(7))

private_law_LSOA$Percentile_label =
  as.integer((100*private_law_LSOA$Rank_per)) # changed this so that
## It was 0-99 like the SAS - the min and max will differ from 0 and 100 by 1/n

## The private law percentiles are exported and an excel file creates the adjustments that need to be made to the main weights. This happens in the main part of the code.
write.csv(private_law_LSOA, file="private_law_income_percentiles.csv")

## ##########################################################  ##
## Next step is to 'Run_the_remission_test.R
