## ######################################### ##

## Migrating to the new s3tools
#  Using botor as a replacement of aws.s3

## ######################### Setting up Data ####################### ##
## Function create_data_object
## Creates data objects from s3 csv files and
## Return RDA objects
## Output: RDA object


## input arguments: -----------------------------------------------------

##FUN : function to read different type of data
FUN <- data.table::fread


s3_path = "s3://alpha-help-with-fees-model/_1_frs_psm_manipulation.csv"
## Read in psm data in and save it into psm_data as a data.table
psm_data <- botor::s3_read(s3_path, FUN)


## Check the dataset summary to assure there is no need for the data cleaning
## , manipulation and pre-processing stages
summary(psm_data)

## ######################################################  ##
## s3_path : path_s3_bucket_csv : an string path to a S3 bucket CSV file
s3_path <- "s3://alpha-help-with-fees-model/_1_frs_psm_manipulation.csv"

# ## dataset_type : based on if_else(condition, true, false, missing = NULL)
# ## ## condition
# ## tibble: 1 (default)
# ## data frame: 2
# dataset_type <- 2 # data frame
#
# ## output:
# ## dt : data table from red_using function
# ## Read S3 bucket CSV file and convert it to a data.table and then data frame
# df  <- create_data_object(FUN, s3_path, dataset_type, rda_df)
# # Create a dataframe called WeightingsDF from the data imported from the PSM dataset (_1_frs_psm_manipulation.csv)

# and for a data.table
datat <- botor::s3_read(s3_path, FUN)

WeightingsDF <- datat
