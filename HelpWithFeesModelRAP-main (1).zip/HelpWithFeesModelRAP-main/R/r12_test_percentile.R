## ##################################################################  ##
## CREATE THE PRIVATE LAW PERCENTILES
## First, the equvalised PSM income is ranked and arranged into percentiles.
## This percentiles are adjusted to match the private law distribution in the 'set_up_weights' code.

#SAS: I have kept percentiles to where income is greater than zero, as this excludes people living at home with
#SAS: parents which could otherwise distort the data*/
##
## This code creates a new variable where households with zero income is set to 'NA'
##
## ###################  old code:#################################  ##
##
# df_working$monthlyincome_equivalised_no_zero =
#   df_working$monthlyincome_equivalised

# df_working$monthlyincome_equivalised_no_zero[df_working$monthlyincome_equivalised_no_zero == 0] <- NA
## ###################  new code:#################################  ##
df_working <-
  df_working %>%
  filter(!(monthlyincome_equivalised == 0)) %>%
  mutate(monthlyincome_equivalised_no_zero = monthlyincome_equivalised)

# df_working <-
#   df_working %>%
#   mutate(monthlyincome_equivalised_no_zero =
#            if_else(monthlyincome_equivalised != 0,
#                     as.numeric(df_working$monthlyincome_equivalised_no_zero), NA))

## this code creates the percentiles by household income
## ###################  old code:#################################  ##

# p = seq(0, .99, by=.01)
# percentiles =
#   quantile(df_working$monthlyincome_equivalised, p,
#            weights = WeightingsDF_2$PSM_Grossing_Factor,
#            type = 2, na.rm = TRUE)

## ###################  new code:#################################  ##
percentiles =
  quantile(as.numeric(df_working$monthlyincome_equivalised_no_zero),
           probs = seq(0, .99, by=.01),
           weights = as.numeric(WeightingsDF_2$PSM_Grossing_Factor),
           type = 2, na.rm = TRUE)

percentiles[101] =
  max(as.numeric(df_working$monthlyincome_equivalised_no_zero))

#this code assigns a percentile to each benefit unit
rows_along <- function(d) seq(nrow(d))

rtotal = length(rows_along(df_working))

Percentages <- vector("numeric", rtotal)

for(i in 1:rtotal) {
  Percentages[i] =
    (min(which(percentiles >=
                 as.numeric(df_working$monthlyincome_equivalised_no_zero)[i]))-1)
}

Percentages[sapply(Percentages, is.infinite)] <- NA

df_working$Percentages <- Percentages

#put those with zero income into the first percentile
#LD commit checker
#amend code so that if 'NA' it's in 1. This should work.
df_working <-
  df_working %>%
  mutate(Percentages =
           ifelse(is.na(Percentages) | Percentages == 0,
                  1 , Percentages))

income_percentiles <-
  df_working %>%
  group_by(Percentages) %>%
  summarise(PSM_Grossing_Factor = sum(PSM_Grossing_Factor))

write.csv(income_percentiles, file="income_percentiles.csv")

## bring in adjustments to private law weights
## FUN : function to read different type of data (tibble)
FUN <- readr::read_csv

## s3_path : path_s3_bucket_csv : an string path to a S3 bucket CSV file
s3_path <- "s3://alpha-help-with-fees-model/Private Law Weight Adjustment.csv"
## Read in Private Law Weight Adjustment data in and save it into
## privatelaw_weight as a data.table
##
privatelaw_weight <- botor::s3_read(s3_path, FUN, show_col_types = FALSE)

## merge the weight onto the main dataset and create the weight
## ###################  old code:#################################  ##
# df_working <- merge( df_working, privatelaw_weight, by="Percentages")
# df_working <- df_working %>% mutate(priv_law_weight= Private_Law_Weight_Adjustment*PSM_Grossing_Factor)


## ###################  new code:#################################  ##
df_working <-
  df_working %>%
  merge(privatelaw_weight, by="Percentages")

df_working <-
  df_working %>%
  mutate(priv_law_weight=
           Private_Law_Weight_Adjustment*PSM_Grossing_Factor)

## ###############################################################  ##


## checking the new weight gives the correct distribution
Re_weighted_table <- df_working %>%
  group_by(Percentages) %>%
  summarise(total_private_law_weight =
              sum(priv_law_weight))


write.csv(Re_weighted_table, file="Re_weighted_table.csv")

