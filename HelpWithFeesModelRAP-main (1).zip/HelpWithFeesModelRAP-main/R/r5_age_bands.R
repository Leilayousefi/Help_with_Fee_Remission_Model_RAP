## ######################################### ##

## Migrating to Case_when() to create new variable
#  Using Case_when as a replacement of ifelse
### Case_when() to create new variable and Calculate age bands
#This section takes the recorded age of respondents (in years) and sorts it into the appropriate age band
WeightingsDF <- WeightingsDF %>%
  # filter(
  #   !(is.na(age_band_head))
  # ) %>%
  mutate(age_band_head = case_when(
  FRS_Person_1_Age >=16 & FRS_Person_1_Age <=24   ~ "16 to 24",
  FRS_Person_1_Age >=25 & FRS_Person_1_Age <=34   ~ "25 to 34",
  FRS_Person_1_Age >=35 & FRS_Person_1_Age <=44   ~ "35 to 44",
  FRS_Person_1_Age >=45 & FRS_Person_1_Age <=54   ~ "45 to 54",
  FRS_Person_1_Age >=55 & FRS_Person_1_Age <=64   ~ "55 to 64",
  FRS_Person_1_Age >=65 & FRS_Person_1_Age <=74   ~ "65 to 74",
  FRS_Person_1_Age >=75 ~ "75+",
  FALSE ~ "0" )) ##as.character(age_band_head)))#TRUE ~ "0"TRUE ~ as.numeric(as.character(age_band_head)


#This section takes the recorded age of respondents (in years) and sorts it into the appropriate age band for divorce.
#This uses narrower bands than age_band_head
WeightingsDF <- WeightingsDF %>%
  mutate(Divorce_age = case_when(
  FRS_Person_1_Age < 20 ~ "<24",
  FRS_Person_1_Age >=20 & FRS_Person_1_Age <=24   ~ "20 to 24",
  FRS_Person_1_Age >=25 & FRS_Person_1_Age <=29   ~ "25 to 29",
  FRS_Person_1_Age >=30 & FRS_Person_1_Age <=34   ~ "30 to 34",
  FRS_Person_1_Age >=35 & FRS_Person_1_Age <=39   ~ "35 to 39",
  FRS_Person_1_Age >=40 & FRS_Person_1_Age <=44   ~ "40 to 44",
  FRS_Person_1_Age >=45 & FRS_Person_1_Age <=49   ~ "45 to 49",
  FRS_Person_1_Age >=50 & FRS_Person_1_Age <=54   ~ "50 to 54",
  FRS_Person_1_Age >=55 & FRS_Person_1_Age <=59   ~ "55 to 59",
  FRS_Person_1_Age >=60 ~ "60+",
  FALSE ~ "0" )) #TRUE ~ as.character(Divorce_age)))#TRUE ~ "0"TRUE ~ as.numeric(as.character(age_band_head)

# Another way for Creating age bandings
# WeightingsDF$age_band_head <- cut(table$age,
#                                   breaks = c( 16, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, Inf),
#                                   labels = c("16 to 24", "25 to 34", "35 to 44", "45 to 54",
#                                              "55 to 64", "65 to 74",
#                                              "75+"),
#                                   right = FALSE)
## ######################################### ##

#Generate flag for self-employment status
WeightingsDF <- WeightingsDF %>%
  dplyr::mutate(self_employed =
           ifelse(FRS_Employ_Type_person_1==2,1,0))
