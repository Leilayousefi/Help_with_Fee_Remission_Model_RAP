## #################  Setting Up variables    ######################## ##

## Cleaning, Migrating and simplifying
## Using filter() function is used to subset a data frame,
## retaining all rows that satisfy the conditions.

## ######################### Setting up Data ####################### ##
## Function create_data_object
## Creates data objects from s3 csv files and
## Return RDA objects
## Output: RDA object

## input arguments: -----------------------------------------------------
## ######################################### ##

## Migrating to the new s3tools
#  Using botor as a replacement of aws.s3

## Create df_working dataframe by taking copy of WeightingsDF_2 datframe from Set_up_Weights.R
## This was done during model development to ensure that there was a clean copy of the original dataframe to roll back to.
## It's not strictly necessary to do this when the model is operating normally, but will be useful when making changes
df_working <- WeightingsDF_2

#'Create a new variable called EM_JSA
#If PSM_L_Income_Support_Wk > 0 and PSM_Income_Support_Type is 2 or 3
#then EM_JSA = PSM_L_Income_Support_Wk, otherwise it is zero
df_working <-
  df_working %>% mutate(
    EM_JSA_Wk = if_else(
      PSM_L_Income_Support_Wk > 0 &
        PSM_Income_Support_Type %in% c(2, 3),
      PSM_L_Income_Support_Wk,
      0
    )
  )


df_working <-
  df_working %>% mutate(
    PSM_L_Income_Support_Wk = ifelse(
      PSM_L_Income_Support_Wk > 0 &
        PSM_Income_Support_Type %in% c(2, 3),
      0,
      PSM_L_Income_Support_Wk
    )
  )


## Create earning level variable
#'A' in PSM_Earnings_Spouse_Wk filtered out by as.numeric and is.na and set to 0
## This is done as the EM_Earnings_Spouse_Wk column needs to contain numeric values only or the logic won't work on it
df_working <-
  df_working %>%
  mutate(EM_Earnings_Spouse_Wk =
           replace(PSM_Earnings_Spouse_Wk,
                   PSM_Earnings_Spouse_Wk == 'A', 0)) #Removes A's

df_working <-
  df_working %>%
  mutate(EM_Earnings_Spouse_Wk =
           as.numeric(EM_Earnings_Spouse_Wk)) #sets column class to numeric

df_working <-
  df_working %>%
  mutate(EM_Earnings_Spouse_Wk =
           replace(EM_Earnings_Spouse_Wk,
                   EM_Earnings_Spouse_Wk < 0, 0))  #Sets negative values to 0



## Add the cleaned-up spouse earnings to head of household earnings
df_working <-
  df_working %>%
  mutate(BU_Earnings_Wk =
           EM_Earnings_Spouse_Wk + PSM_Earnings_Head_Wk)

df_working <-
  df_working %>%
  mutate(BU_Earnings_A =
           BU_Earnings_Wk * 52)

