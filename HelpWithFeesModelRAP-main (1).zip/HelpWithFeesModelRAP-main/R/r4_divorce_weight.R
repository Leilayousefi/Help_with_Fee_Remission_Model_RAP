## ######################### Setting up Data ####################### ##
## Function create_data_object
## Creates data objects from s3 csv files and
## Return RDA objects
## Output: RDA object

## input arguments: -----------------------------------------------------


## Divorce data------------------------------------------------
## FUN : function to read different type of data - tibble
FUN <- readr::read_csv

## s3_path : path_s3_bucket_csv : an string path to a S3 bucket CSV file
s3_path <- "s3://alpha-help-with-fees-model/divorce_weights.csv"

# civil_weight dataset brings in the adjustment that
# is needed to the weights for civil users.
## Read in divorce_weight data in and save it into divorce_weight as a tibble
divorce_weight <- botor::s3_read(s3_path, FUN, show_col_types = FALSE)
# divorce_weight dataset brings in the adjustment that is
# needed to the weights for divorced users.
