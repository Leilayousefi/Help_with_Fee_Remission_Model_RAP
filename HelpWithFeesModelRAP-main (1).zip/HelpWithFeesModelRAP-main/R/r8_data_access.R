## #################  Data Access    ######################## ##
## Cleaning, Migrating and simplifying
## Using filter() function is used to subset a data frame,
## retaining all rows that satisfy the conditions.

## ######################### Setting up Data ####################### ##
## Function create_data_object
## Creates data objects from s3 csv files and
## Return RDA objects
## Output: RDA object

## input arguments: -----------------------------------------------------
## ######################################### ##

## Migrating to the new s3tools
## Using botor as a replacement of aws.s3

# Read S3 bucket CSV file and convert it to a data.table
## FUN : function to read different type of data (tibble)
FUN <- readr::read_csv

## s3_path : path_s3_bucket_csv : an string path to a S3 bucket CSV file
s3_path <- "s3://alpha-help-with-fees-model/Copy of File_5_-_IoD2019_Scores.csv"

## dataset_type tibble: 1 (default)

# civil_weight dataset brings in the adjustment that
# is needed to the weights for civil users.
deprivation_scores <- botor::s3_read(s3_path, FUN, show_col_types = FALSE)

## ----------------------------------------------------------------------
## bring in the adjustment that is needed to the weights for civil users.
s3_path <- "s3://alpha-help-with-fees-model/PRIVATE_LAW_anonymised_with_LSOA.csv"

## This dataset brings in the adjustment that
## is needed to the weights for civil users.
private_law_LSOA <- botor::s3_read(s3_path, FUN, show_col_types = FALSE)

## Migrating to the new s3tools
##  Using botor as a replacement of aws.s3

## This code sets up the private law weight. The private law weight is created by creating income
## Deprivation percentiles and attaching these to the private law dataset using LSOA.


