## ###################################################################  ##
## #####################  Calculating HwF thresholds #################  ##
#This calculates the thresholds from the number of other adults in the household and the number of children
df_working <-
  df_working %>% mutate(
    threshold = incomethreshold + ((FRS_Adult_Count_BU - 1) * couplepremium) + (children_under_14 *
                                                                                  childpremium) + (children_14plus * couplepremium)
  )

#Calculates the income for the purposes of the HwF income test
#Some benefits are not included in this calculation, represented here by Disregarded_Income_Legacy_M/Disregarded_Income_UC_M
df_working <-
  df_working %>% mutate(HwF_income_legacy_m = EM_GrossInc_M - Disregarded_Income_Legacy_M)

df_working <-
  df_working %>% mutate(HwF_income_uc_m = EM_Income_Under_UC_M - Disregarded_Income_UC_M)

#Beginning of for loop
#This runs the code once for each separate fee specified in the fee variable (set in parameters above)
#The loop ends after writing a csv file containing the sum of fee_due_weighted and remissions_weighted
#This initialises a variable called fee_count which is given a value of 1 to the number of elements within the fee vector
#Once fee_count exceeds the number of elements in the fee vector, the loop exits
for (fee_count in 1:length(fee)) {

  #Find name of current fee
  fee_type = 1

  #This is a short loop that works through the index of fees and sets fee_type equal to the fee's position in the index
  for (fee_type_count in 1:length(index_of_fees)) {if(fee[fee_count] == index_of_fees[fee_type_count]) fee_type <- fee_type_count}

  #The Fee_type variable is then used to create the appropriate name for the current fee under test
  df_name_legacy <- paste(fee_type_description[fee_type],"_legacy_weighted",sep="")
  df_name_UC <- paste(fee_type_description[fee_type],"_UC_weighted",sep="")

  #Setting the disposable capital threshold
  #Need to set capital threshold that varies with the fee
  #Threshold set to 16000 if at least one member of the household is older than 61
  #Otherwise:
  #       If fee <=£1,000, then threshold set to £3,000
  #       If fee >£1,000 and <=£1,335 then threshold set to £4,000
  #       If fee >£1,335 and <=£1,665 then threshold set to £5,000
  #       If fee >£1,665 threshold set to £14,000
  df_working <- df_working %>% mutate(
    disposable_capital_threshold =if_else((FRS_Person_1_Age >= 61 |
                                            FRS_Person_2_Age >= 61), 16000,
                                          (if_else(fee[fee_count] > 1000 &
                                                    fee[fee_count]<=1335, 4000,
                                                  if_else(fee[fee_count]>1335 &
                                                            fee[fee_count]<=166
                                                          ,5000,
                                                          (if_else(fee[fee_count]
                                                                      >6000,
                                                                      1400
                                                                      ,3000
                                                                      )
                                                           )
                                                          )
                                                  )
                                           )
                                          )
    )


  #Dataset for legacy remissions - not currently used (can skip straight to UC)
  df_legacy <- df_working

  df_legacy <-
    df_legacy %>% mutate(pass_capital_test = if_else(FRS_Capital > disposable_capital_threshold, "No", "Yes"))
  df_legacy <-
    df_legacy %>% mutate(remission = if_else(pass_capital_test == "No", "None", "Missing"))
  df_legacy <-
    df_legacy %>% mutate(remission = if_else(passport_legacy == 1 &
                                               remission == "Missing", "Full", remission))
  df_legacy <-
    df_legacy %>% mutate(
      remission = if_else(
        remission == "Missing" &
          HwF_income_legacy_m > threshold + partialthreshold,
        "None",
        remission
      )
    )
  df_legacy <-
    df_legacy %>% mutate(
      remission = if_else(
        remission == "Missing" &
          HwF_income_legacy_m < threshold,
        "Full",
        remission
      )
    )
  df_legacy <-
    df_legacy %>% mutate(
      remission = if_else(
        remission == "Missing" &
          HwF_income_legacy_m >= threshold &
          HwF_income_legacy_m <= (threshold + partialthreshold),
        "Partial",
        remission
      )
    )

  #Dataset for UC remissions
  #The following lines calculate whether or not an applicant would qualify for HwF
  df_UC <- df_working
  df_UC <-
    df_UC %>% mutate(pass_capital_test = if_else(FRS_Capital > disposable_capital_threshold, "No", "Yes")) #This checks if an applicants' capital exceeds the threshold
  df_UC <-
    df_UC %>% mutate(remission = if_else(pass_capital_test == "No", "None", "Missing")) #If an applicant fails the capital test, they are flagged as having no remission
  df_UC <-
    df_UC %>% mutate(remission = if_else(passport_UC == 1 &
                                           remission == "Missing", "Full", remission)) #If an applicant does not exceed the capital threshold, and is passported because of the benefits they recieve, they are flagged as having a full remission

  #If an passes the capital test applicant is not passported via benefits, their eligibility is checked against their income
  #If income exceeds the threshold and partial threshold, they are flagged as having no remission
  df_UC <-
    df_UC %>% mutate(
      remission = if_else(
        remission == "Missing" &
          HwF_income_uc_m > threshold + partialthreshold,
        "None",
        remission
      )
    )

  #If income is below the threshold, they are flagged as having full remission
  df_UC <-
    df_UC %>% mutate(remission = if_else(
      remission == "Missing" &
        HwF_income_uc_m < threshold,
      "Full",
      remission
    ))

  #If income is at or above the threshold, and at or below (threshold + partial threshold) they are flagged as having partial remission
  df_UC <-
    df_UC %>% mutate(
      remission = if_else(
        remission == "Missing" &
          HwF_income_uc_m >= threshold &
          HwF_income_uc_m <= (threshold + partialthreshold),
        "Partial",
        remission
      )
    )


  #REMISSION VALUES
  #Income - the threshold is rounded down to the nearest £10 when calculating the partial award, as per the guidance

  #df_legacy remission values
  #Sets up remission_value, partial_threshold, partial_threshold10, Fee_Due, and Group variables for df_legacy dataframe

  #If remission flag is "Full", remission is equal to fee value
  df_legacy <-
    df_legacy %>% mutate(remission_value = if_else(remission == "Full", fee[fee_count], NULL))

  #If remission flag is "None", remission is zero
  df_legacy <-
    df_legacy %>% mutate(remission_value = if_else(remission == "None", 0, remission_value))

  #If remission flag is "Partial", code calculates partial remission value
  df_legacy <-
    df_legacy %>% mutate(partial_threshold = HwF_income_legacy_m - threshold)
  df_legacy <-
    df_legacy %>% mutate(partial_threshold10 = round(floor(partial_threshold /
                                                             10) * 10, -1))
  df_legacy <-
    df_legacy %>% mutate(
      remission_value = if_else(
        remission == "Partial" &
          partial_threshold10 / 2 < fee[fee_count],
        fee[fee_count] - partial_threshold10 / 2,
        0
      )
    )

  df_legacy <-
    df_legacy %>% mutate(Fee_Due = fee[fee_count])
  df_legacy <-
    df_legacy %>% mutate(remission_value = if_else(remission_value > fee[fee_count], fee[fee_count], remission_value))
  df_legacy <-
    df_legacy %>% mutate(Group = if_else(passport_legacy == 1 &
                                           remission == "Full", 1, 0))

  #df_UC remission values
  #Sets up remission_value, partial_threshold, partial_threshold10, Fee_Due, and Group variables for df_UC dataframe
  #Code is basically the same as that in the previous section, but points at the df_UC dataframe rather than df_legacy

  #If remission flag is "Full", remission is equal to fee value
  df_UC <-
    df_UC %>% mutate(remission_value = if_else(remission == "Full", fee[fee_count], 0))

  #If remission flag is "None", remission is zero
  df_UC <-
    df_UC %>% mutate(remission_value = if_else(remission == "None", 0, remission_value))

  #If remission flag is "Partial", code calculates partial remission value
  df_UC <-
    df_UC %>% mutate(partial_threshold = HwF_income_uc_m - threshold)
  df_UC <-
    df_UC %>% mutate(partial_threshold10 = round(floor(partial_threshold /
                                                         10) * 10, -1))
  df_UC <-
    df_UC %>% mutate(
      remission_value = if_else(
        remission == "Partial" & partial_threshold10 / 2 < fee[fee_count],
        fee[fee_count] - partial_threshold10 / 2,
        remission_value
      )
    )
  df_UC <-
    df_UC %>% mutate(
      remission_value = if_else(
        remission == "Partial" & partial_threshold10 / 2 >= fee[fee_count],
        0,
        remission_value
      )
    )

  df_UC <-
    df_UC %>% mutate(Fee_Due = fee[fee_count])
  df_UC <-
    df_UC %>% mutate(remission_value = if_else(remission_value > fee[fee_count], fee[fee_count], remission_value))
  df_UC <-
    df_UC %>% mutate(Group = if_else(passport_UC == 1 &
                                       remission == "Full", 1, 0))



  #df_legacy_weighted
  #Calculates the weighted value of the remissions and fee due by multiplying the remission value by the appropriate fee_type_weight (e.g. HwF_civil_Weight)
  legacy_weighted_temp <-
    df_legacy %>% mutate(Remission_Weighted = ifelse(remission_value > 0, remission_value * get(fee_type_weight[fee_type]), 0))
  legacy_weighted_temp <-
    legacy_weighted_temp %>% mutate(Fee_Due_Weighted = Fee_Due * get(fee_type_weight[fee_type]))

  #df_UC
  UC_weighted_temp <-
    df_UC %>% mutate(Remission_Weighted = ifelse(remission_value > 0, remission_value * get(fee_type_weight[fee_type]), 0))
  UC_weighted_temp <-
    UC_weighted_temp %>% mutate(Fee_Due_Weighted = Fee_Due * get(fee_type_weight[fee_type]))


  #Creates two new dataframes called SUM_of_Remission_Weighted and SUM_of_Fee_Due_Weighted
  #These contain two values for the fee currently under test: the sum of all remissions; and the sum of fees due
  SUM_of_Remission_Weighted <-
    sum(UC_weighted_temp$Remission_Weighted)
  SUM_of_Fee_Due_Weighted <- sum(UC_weighted_temp$Fee_Due_Weighted)
  df_Output <-
    data.frame(SUM_of_Remission_Weighted, SUM_of_Fee_Due_Weighted)

  ## Write file containing SUM_of_Remission_Weighted and SUM_of_Fee_Due_Weighted:
  ##
  ##  ###############  old code   ##############################  ##

  # write.csv(df_Output, file = paste("Output/", file_names[fee_type], ".csv", sep = ""))

  ## ################# New code #################### ##
  ## corresponding s3 path to the data file
  ## s3_path : path_s3_bucket_csv : an string path to a S3 bucket CSV file
  ## Concatenate vectors after converting to character.
  s3_path <- paste0("s3://", "alpha-help-with-fees-model", "/", "Output/", file_names[fee_type], ".csv")
  # takes an R object, a write function with file as a parameter specifying the path to the data, and a full S3 path as parameters.
  botor::s3_write(as.data.frame(df_Output), readr::write_csv, s3_path)

  #Store values of sums and write to a new dataframe
  #As loop progresses, new rows are added to build up a table with all values in
  Output_SUMS <-
    rbind(
      Output_SUMS,
      data.frame(
        "SUM_of_Remission_Weighted" = SUM_of_Remission_Weighted,
        "SUM_of_Fee_Due_Weighted" = SUM_of_Fee_Due_Weighted,
        row.names = file_names[fee_type]
      )
    )
}

#***End of loop

#Displays the values of all SUM_of_Remission_Weighted and SUM_of_Fee_Due_Weighted and writes these to a csv file
view(Output_SUMS)
##
##
##  ###############  old code   ##############################  ##

# write.csv(Output_SUMS,"2019_remissionstest.csv")

## ################# New code #################### ##
## corresponding s3 path to the data file
## s3_path : path_s3_bucket_csv : an string path to a S3 bucket CSV file
## Concatenate vectors after converting to character.
s3_path <- paste0("s3://", "alpha-help-with-fees-model", "/", "2019_remissionstest", ".csv")
# takes an R object, a write function with file as a parameter specifying the path to the data, and a full S3 path as parameters.
botor::s3_write(as.data.frame(Output_SUMS), readr::write_csv, s3_path)
