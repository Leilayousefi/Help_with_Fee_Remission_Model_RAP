## ######################################### ##
## #################  Setting Up Structure of Parameters   ######################## ##
##

## Merging on the weights## ######################################### ##
## convert age_bands to a factor
WeightingsDF$age_band_head <- forcats::as_factor(WeightingsDF$age_band_head)
## ## ######################################### ##
##
## Migrating to join for Merging on the weights
#  Using left_join as a replacement of merge
##left_join(df_primary, df_secondary, by = c('ID', 'year'))

#Create a new dataframe (WeightingsDF_2) from a merger of WeightingsDF and the civil_weight dataframe from CCUS_weights.csv
WeightingsDF_2 <-
  dplyr:::left_join.data.frame(
    WeightingsDF, civil_weight, by=c('age_band_head','self_employed'))

## convert age_bands to a factor
WeightingsDF_2$Divorce_age <- forcats::as_factor(WeightingsDF_2$Divorce_age)

#Now merge in the divorce_weight dataframe from divorce_weights.csv
WeightingsDF_2 <-
  dplyr:::left_join(
    WeightingsDF_2, divorce_weight, by='Divorce_age')

head(WeightingsDF_2)
