d = c(1, 2, 3)

rename_rda <- function(x){
  x2 <- log(x)

  arg_name <- deparse(substitute(x)) # Get argument name
  var_name <- paste("log", arg_name, sep="_") # Construct the name
  assign(var_name, x2, env=.GlobalEnv) # Assign values to variable
  # variable will be created in .GlobalEnv
}
