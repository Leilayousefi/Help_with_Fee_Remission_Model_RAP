## ######################################################################## ##
## ######################################################################## ##
## Setting parameters for testing ---------------------------------------------
## ######################################################################## ##
## ######################################################################## ##


## Calculate remissions
#Setting parameters
#Need to configure this so it checks against the fee and applies the correct weights and file names
#Fee variable can be a vector of values - in this case, the model will run each of the fee values sequentially and provide outputs for each of them
#This uses the file_names list (see below) to create names for the output files/output rows
fee <- c(188, 1426, 6067, 1175, 593, 232, 48, 633)

#The next four lines set the HwF income threshold, couple premium, child premium and the partial threshold
incomethreshold <- 1170
couplepremium <- 175
childpremium <- 265
partialthreshold <- 4000
dates_for_file <- format(Sys.Date(), "%Y%m%d")
file_names <-
  #creates a list of file names with the current date at the end
  c(
    paste("civil_main_infl_thres_", dates_for_file, sep = ""),
    paste("civil_mid_infl_thres_", dates_for_file, sep = ""),
    paste("civil_high_infl_thres_", dates_for_file, sep = ""),
    paste("hearing_fee_infl_thres_", dates_for_file, sep = ""),
    paste("divorce_infl_thres_", dates_for_file, sep = ""),
    paste("private_law_infl_thres_", dates_for_file, sep = ""),
    paste("rcj_low_infla_thres_", dates_for_file, sep = ""),
    paste("rcj_high_infla_thres_", dates_for_file, sep = "")
  )

#Sets up index of fees and matches current fee(s) to them
#This allows the model to be run against a single fee, specified in line 320, and the code will automatically assign the correct weight
#This will work as long as the fee in line 320 matches one of the fees in the index_of_fees vector
index_of_fees <- c(188, 1426, 6067, 1175, 593, 232, 48, 633)
fee_type_description = c("civil_main","money_mid","money_high", "hearing", "Divorce","Private_Law","RCJ_low", "RCJ_high")
fee_type_weight = c("HwF_civil_weight","HwF_civil_weight","HwF_civil_weight","HwF_civil_weight","HwF_divorce_weight","priv_law_weight", "HwF_civil_weight", "HwF_civil_weight")

#Sets up the Output_SUMS dataframe to contain the results of the fees loop
#nrow is zero, because headings are there (on row zero), but there's no data yet (which will go into row 1 and onwards)
Output_SUMS <-
  setNames(data.frame(matrix(ncol = 2, nrow = 0)),
           c("SUM_of_Remission_Weighted", "SUM_of_Fee_Due_Weighted"))
