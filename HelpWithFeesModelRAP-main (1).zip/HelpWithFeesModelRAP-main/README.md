# Help-with-Fees-Model-RAP
Migrating Help with Fees (HwF) Model for Court users to a 
Reproducible Analytical Pipelines (RAP) version. 

title: "Help_with_Fee_Remission_Model_RAP"
output: R markdown in html_document
Author: Leila Yousefi
This Package is written for Ministry of Justice (MoJ)
## ######################################### ##

## old version 

PSM based model to calculate changes to the Help with Fees remissions scheme.

The model should be run in the following order: a) Run the ''set up weights' code to set up the weights used in the modelling; b) Run the 'run the remissions test code' to set up the PSM data and run the HwF means test on this population

To run an alternative HwF option, you should copy the code into a branch and edit it to run an alternative remissions test there.
## ############################################### ##

## Acknowledgement

The concept of a Reproducible Analytical Pipeline (RAP) was 
created by Matthew Upson and Matthew Gregory at the Government Digital Service. 

https://dataingovernment.blog.gov.uk/2017/03/27/reproducible-analytical-pipeline/

https://ukgovdatascience.github.io/rap_companion/

https://ukgovdatascience.github.io/rap_companion/why.html#why-learning-to-rap-might-be-hard

https://www.isdscotland.org/About-ISD/Methodologies/_docs/Reproducible_Analytical_Pipelines_paper_v1.4.pdf

https://ukgovdatascience.github.io/rap_companion/exemplar.html#tidy-data

https://software-carpentry.org/lessons/



## Determine whether work is reproducible, some key questions1 to ask are:
· Is it clear where to begin?
· Can you determine which inputs produced which outputs?
· Which is the most recent copy of the code?
· What files can I safely delete, and should I delete files at all?
· Are scripts and reports version controlled?
· Are there lots of manual steps in the process?
· Are proprietary software used in the process?

## A Reproducible Analytical Pipeline should be:

# 1. Reproducible
This is achieved through the use of open source software, R Projects, package 
management and ideally computing environment management.
# 2. High quality
This is achieved by removing manual steps in the production process which increase the 
risk of errors and incorporating data QA and unit testing of R functions into the pipeline.
# 3. Auditable
This is achieved through the use of version control and documentation of R functions and 
code.
# 4. Sustainable
This is achieved through training and up skilling of staff – “sustainability is social, not 
technical” (Matthew Upson, 2018) and requires everyone in a team to know how to use and 
update the pipeline.

## ######################################### ##

## Pick the RAP battle wisely

## DIY principle:
# Do not repeat yourself
instead of copy-pasting piece of code, RAPing the R package 

Periodic, customer need is likely to stay constant, business critical, time consuming but straight forward, consistent output format, we can publish it all except our internal data which we can hold locally, customers might like to check our analysis thus improving our transparency objectives

# Drawing data from many disparete sources

As it is NOT a one off report you might not benefit from the time investment of upskilling. 
You are NOT likely time pressured so we do NOT suggest carrying on with this using your traditional methods.

## Establishing the minimal tidy dataset

Read this paper by Hadley Wickham on tidy data.
