install.packages("devtools")
library(devtools)

#>
#> Attaching package: 'testthat'
#> The following object is masked from 'package:devtools':
#>
#>     test_file
devtools::session_info()


#> create package

## devtools::create("/home/leila-yousefi/R_Projects/HelpWithFeesModelRAP)")

library(HelpWithFeesModelRAP)


install.packages("remotes")
library(remotes)

remotes::install_git("git@github.com:moj-analytical-services/Rs3tools.git")


# install renv if it doesn't exist on your system
if(!"renv" %in% installed.packages()[, "Package"]) install.packages("renv")
# Remove bare = TRUE if you'd like to move your existing packages over to
# renv. This is not a good idea if you're migrating from s3tools as
# renv will attempt to install that library.
renv::init(bare = TRUE)
# Tell renv to use Python and set up a virtual environment
# if you get an error here, remove the python path argument and
# manually select the version of python you require
#
# If this process goes wrong run

## renv::deactivate()
## in the terminal and

## rm -rf renv renv.lock .Rprofile requirements.txt

#
#
renv::use_python(python='/usr/bin/python')
#renv::use_python('renv/venv/bin/python')

# Install reticulate so we can make calls to Python libraries, required by botor
renv::install('reticulate')

# Install the Python library, boto3, used by botor to access S3
reticulate::py_install('boto3')

# Install botor itself
renv::install('botor')

#remotes::install_git("git@github.com:moj-analytical-services/botor.git")


#
#
renv::use_python(python='/usr/bin/python')
#renv::use_python('renv/venv/bin/python')

# Install reticulate so we can make calls to Python libraries, required by botor
renv::install('reticulate')

# Install the Python library, boto3, used by botor to access S3
reticulate::py_install('boto3')

# Install botor itself
renv::install('botor')

#remotes::install_git("git@github.com:moj-analytical-services/botor.git")


# git clone git@github.com:moj-analytical-services/user-guidance.git

##renv::install("botor@0.3.0")


## if error in terminal:
## and restart your R session.
## On earlier test versions it’s not quite that simple:
## First open your project, and in the console run
##
## if(!"renv" %in% installed.packages()[, "Package"]) install.packages("renv")
# Remove bare = TRUE if you'd like to move your existing packages over to
# renv. This is not a good idea if you're migrating from s3tools as
# renv will attempt to install that library.
##renv::init(bare = TRUE)
##
## create a Python virtual environment.
# python3 -m venv renv/venv --without-pip --system-site-packages
#
#
## Not run:

# use python with a project
##renv::use_python()

# use python with a project; create the environment
# within the project directory in the '.venv' folder
##renv::use_python(name = ".venv")

# use python with a pre-existing virtual environment located elsewhere
##renv::use_python(name = "~/.virtualenvs/env")

# use virtualenv python with a project
##renv::use_python(type = "virtualenv")

# use conda python with a project
##renv::use_python(type = "conda")

## End(Not run)
##~/.virtualenvs/venv/bin/python
###renv::use_python(type = "auto")


#renv::install('Rcpp@1.0.7')
#

###
###
###
#### Install reticulate so we can make calls to Python libraries, required by
# botor




#in the terminal and

#rm -rf renv renv.lock .Rprofile requirements.txt
#in the terminal, restart your R session, and start again.

#You should now be able to use library(botor) as usual, and renv::snapshot()
#to lock the R and Python library versions for recreation by collaborators or within a deployment.

#dbtools (i.e. the R wrapper for pydbtools)
#is the data engineering maintained package for accessing Athena databases
#from R. It requires a little setup:

##renv::use_python()

## reticulate::py_install("pydbtools")

remotes::install_github("moj-analytical-services/dbtools")

#
renv::consent()

## #################  Installing Required Pachages  ######################## ##
##
##
packages = c("usethis", "roxygen2", "testthat", "tidyverse", "knitr", "tidyr", "dplyr", "ggplot2", "stringr", "dplyr", "data.table", "datasets")#, "botor", "moj-analytical-services/mojverse", "moj-analytical-services/mojrap") #, "moj-analytical-services/xltabr", "s3tools", "aws.s3"

## Now load or install and load all packages listed above
package.check <- lapply(
  packages,
  FUN = function(x) {
    if (!require(x, character.only = TRUE)) {
      install.packages(x, dependencies = TRUE)
      library(x, character.only = TRUE)
    }
  }
)


library(devtools)
devtools::session_info()

#> Loading required package: usethis
library(roxygen2)
library(testthat)

#> Loading required package: usethis
packageVersion("devtools")

#>
#> after creating the function

#use_r("s3_read_using")
#

use_r("create_data_object")

#source("R/create_data_object.R")
#
install.packages("aws.s3")
# library(s3tools)
library(aws.s3)

library(HelpWithFeesModelRAP)

RecruitmentTimeToHire::s3_read_using()
RecruitmentTimeToHire::create_data_object()

load_all()
## If ERROR then delete some .R files from R folder and build it again
##
#### to remove the conflicts.
rm(list = c("create_data_object", "s3_read_using"))
##

load_all()
## If ERROR then delete some .R files from R folder and build it again
##
#### to remove the conflicts.
#rm(list = c("create_data_object", "s3_read_using"))
rm(list = c("create_data_object"))
##
#RecruitmentTimeToHire::s3_read_using()
HelpWithFeesModelRAP::create_data_object()
#The regexcite directory is an R source package and an RStudio Project. Now we make it also a Git repository, with #use_git().
#
devtools::load_all(".")
devtools::document(roclets = c('rd', 'collate', 'namespace'))
devtools::load_all(".")
devtools::check()

#install.packages("moj-analytical-services/RecruitmentTimeToHire")
#library(RecruitmentTimeToHire)
#
library(HelpWithFeesModelRAP)

#RecruitmentTimeToHire::s3_read_using()
# RecruitmentTimeToHire::create_data_object()

#exists("s3_read_using", where = globalenv(), inherits = FALSE)
exists("create_data_object", where = globalenv(), inherits = FALSE)

## use RStudio, open R/create_data_object.R in the source editor and put the cursor somewhere in the create_data_object() function definition. Now do Code > Insert roxygen skeleton.
##library(regexcite)
##

#install('R/')


exists("s3_read_using", where = globalenv(), inherits = FALSE)
exists("create_data_object", where = globalenv(), inherits = FALSE)

## use RStudio, open R/create_data_object.R in the source editor and put the cursor somewhere in the create_data_object() function definition. Now do Code > Insert roxygen skeleton.
##library(regexcite)
##

#install('R/')

##
#
#use_testthat()
#
#use_mit_license()
#
#Edit DESCRIPTION
##
##create_data_object <- function(FUN, s3_path, dataset_type, ...)
FUN <- data.table::fread
dataset_type <- 2 # dataframe

##
##
s3_path <- 's3://alpha-help-with-fees-model/_1_frs_psm_manipulation.csv'

# Read S3 bucket CSV file and convert it to a data.table
# ##
## Creates a dataframe called psmData from the data
## imported from the PSM dataset (_1_frs_psm_manipulation.csv)
#psmData <- s3_read_using(FUN, s3_path)
## psm_csv$ <- forcats::as_factor(psm_csv$)

## Creates data objects from s3 csv files and
## Return RDA objects
weightingsDFobject <- create_data_object(FUN, s3_path, dataset_type)

## RDA object created from the PSM dataset

weightingsDFobject

? weightingsDFobject

??weightingsDFobject

rm(weightingsDFobject)
##
FUN <- data.table::fread
dataset_type <- 1 # tibble

##
## For Divorced court users

s3_path <- 's3://alpha-help-with-fees-model/divorce_weights.csv'
## create_data_object(FUN, s3_path, dataset_type)
divorceObject <- create_data_object(FUN, s3_path, dataset_type)

#divorce_weights_csv <- s3_read_using(FUN, s3_path)

###  divorce_weights_csv$Divorce_age <- forcats::as_factor(dw_divorce_weights_csv$Divorce_age)

#divorceWeightsData <- divorce_weights_csv

## create_data_object(FUN, s3_path, dataset_type)
#divorce_data_obj <- create_data_object(divorceWeightsData, dataset_type)

## creating RDA data object: civilObject
#divorceObject <- usethis::use_data(divorce_data_obj, overwrite = TRUE)

divorceObject

rm(divorceObject)

##
#### For civil court users
##
s3_path <- 's3://alpha-help-with-fees-model/CCUS_weights.csv'
## creating RDA data object: civilObject
civilObject <- create_data_object(FUN, s3_path, dataset_type)
#
#
#civil_weights_csv <- s3_read_using(FUN, s3_path)

###  civil_weights_csv$age_band_head <- forcats::as_factor(civil_weights_csv$age_band_head)

#civilWeightsData <- civil_weights_csv

#civil_data_obj <- create_data_object(civilWeightsData, dataset_type)

## creating RDA data object: civilObject
#civilObject <- usethis::use_data(civil_data_obj, overwrite = TRUE)

civilObject

## Check for documentation
?civilObject


# Read S3 bucket CSV file and convert it to a data.table
# ##
## Creates a dataframe called psmData from the data
## imported from the PSM dataset (_1_frs_psm_manipulation.csv)
#psmData <- s3_read_using(FUN, s3_path)
## psm_csv$ <- forcats::as_factor(psm_csv$)

## Creates data objects from s3 csv files and
## Return RDA objects
weightingsDFobject <- create_data_object(FUN, s3_path, dataset_type)

## RDA object created from the PSM dataset

weightingsDFobject

? weightingsDFobject

??weightingsDFobject

rm(weightingsDFobject)
##
FUN <- data.table::fread
dataset_type <- 1 # tibble

##
## For Divorced court users

s3_path <- 's3://alpha-help-with-fees-model/divorce_weights.csv'
## create_data_object(FUN, s3_path, dataset_type)
divorceObject <- create_data_object(FUN, s3_path, dataset_type)

#divorce_weights_csv <- s3_read_using(FUN, s3_path)

###  divorce_weights_csv$Divorce_age <- forcats::as_factor(dw_divorce_weights_csv$Divorce_age)

#divorceWeightsData <- divorce_weights_csv

## create_data_object(FUN, s3_path, dataset_type)
#divorce_data_obj <- create_data_object(divorceWeightsData, dataset_type)

## creating RDA data object: civilObject
#divorceObject <- usethis::use_data(divorce_data_obj, overwrite = TRUE)

divorceObject

rm(divorceObject)


##
#### For civil court users
##
s3_path <- 's3://alpha-help-with-fees-model/CCUS_weights.csv'
## creating RDA data object: civilObject
civilObject <- create_data_object(FUN, s3_path, dataset_type)
#
#
#civil_weights_csv <- s3_read_using(FUN, s3_path)

###  civil_weights_csv$age_band_head <- forcats::as_factor(civil_weights_csv$age_band_head)

#civilWeightsData <- civil_weights_csv

#civil_data_obj <- create_data_object(civilWeightsData, dataset_type)

## creating RDA data object: civilObject
#civilObject <- usethis::use_data(civil_data_obj, overwrite = TRUE)

civilObject

## Check for documentation
?civilObject

rm(civilObject)

## Updating the licence
##
use_mit_license()

## Edit DESCRIPTION
##
##
## Creating git workflow
##
#git-crypt status
#
## ######################################################### ##
## Documentation
##
## Trigger the conversion of this new roxygen comment
##  into man/civil_data_obj.Rd with document():
document()
