
## Setting up Data
#Implementation of the SAS HwF weightings in R

#Last edit: 02032022
#Edited by: Leila Yousefi


## #################  Data Access    ######################## ##
##
## the PSM dataset that forms the core of the modelling
##
df <- read_using(
  FUN = data.table::fread,
  s3_path = 's3://alpha-help-with-fees-model/_1_frs_psm_manipulation.csv',
  #  startRow = 1,
  #  sheet = 2
)

#Creates a dataframe called WeightingsDF from the data imported from the PSM dataset (_1_frs_psm_manipulation.csv)
WeightingsDF <- as.data.frame(df)
## ###################  RDA object ######################### ##
## go from raw data csv to a RDA object of civil_weight

dt_civil_weight <- read_using(
  FUN = data.table::fread,
  s3_path = 's3://alpha-help-with-fees-model/CCUS_weights.csv',
  #  startRow = 1,
  #  sheet = 2
)

civil_weight_RDAobj <-
  create_data_object(dt_civil_weight)

rm(civil_weight_RDAobj)

## go from raw data csv to a RDA object of divorce_weight

dt_divorce_weight <- read_using(
  FUN = data.table::fread,
  s3_path = 's3://alpha-help-with-fees-model/divorce_weights.csv',
  #  startRow = 1,
  #  sheet = 2
)

divorce_weight_RDAobj <-
  create_data_object(dt_divorce_weight)

rm(divorce_weight_RDAobj)

## ----------------------------------------------- ##


## ######################################### ##

## Rendering development documentation

## make a new changes and see the effect of those changes in the package use:

# cmd(ctrl) + Shift + L
# devtools::load_all(".")

## ######################################### ##
##
# ?RDAobj does not show anything ==>
#  in R folder create a new R code : data.R

# cmd(ctrl) + Shift + D ==>
# devtools::document(roclets = c('rd', 'collate', 'namespace'))

# Thus, see ?RDAobj that shows Rendering development documentation for "RDAobj"

## ######################################### ##
## Check and Testing
##
# devtools::check()

## #################  Setting Up variables    ######################## ##
